﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    public interface IMostrar<T>
    {
       //  string MostrarDatos(T elemento);
       // void RespuestaHilo(T id);

       string MostrarDatos(IMostrar<T> elemento);
    }
}
