﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace EntidadesHechas
{
    public static class GuardaString
    {
        public static bool Guardar(this string texto, string archivo)
        {
            bool existe = ExisteArchivo(texto, archivo);
            bool escribe = false;
            if (existe != false)
            {
                
                try
                {
                    using (StreamWriter file = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + archivo, true))
                    {
                        file.WriteLine(texto);
                        file.Close();
                        escribe = true;
                    }
                }
                catch (Exception e)
                {

                    throw new Exception("No se puedo  generar el archivo", e);
                }
            }


            return escribe;  
        }

        public static bool ExisteArchivo(this string texto, string archivo)
        {
            bool retorno = false;
            try
            {
                using (StreamReader file = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + archivo))
                {
                    archivo = file.ReadToEnd();
                    file.Close();
                }
                retorno = true;
            }
            catch (Exception e)
            {

                throw new Exception("No se pudo encontrar el archivo", e);
                retorno = false;//Linea no  necesaria
            }
            return retorno;

        }
        /*
         public string Bitacora
        {
            get
            {
                string datos="";
                try
                {
                    using (StreamReader file = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "bitacora.txt"))
                    {
                        datos = file.ReadToEnd();
                        file.Close();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("El archivo no se pudo abrir", e);
                }
                return datos;
            }

            set
            {
                try
                {
                    using (StreamWriter file = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "bitacora.txt", true))
                    {
                        file.WriteLine(value);
                        file.Close();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("El archivo no se pudo generar", e);
                }
            }
        }
         */
    }
}
