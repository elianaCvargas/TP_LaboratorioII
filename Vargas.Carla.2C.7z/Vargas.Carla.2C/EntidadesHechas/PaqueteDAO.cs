﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesHechas
{
    public static class PaqueteDAO//Clase estática que se encargará de guardar los datos de un paquete en la base de datos provista.
    {
        
        private static SqlConnection _conexion;
        private static SqlCommand _comando;
        

        
        static PaqueteDAO()
        {
            PaqueteDAO._conexion = new SqlConnection(Properties.Settings.Default.CadenaConexion);
            PaqueteDAO._comando = new SqlCommand();
            PaqueteDAO._comando.CommandType = System.Data.CommandType.Text;           
            PaqueteDAO._comando.Connection = PaqueteDAO._conexion;
        }

        public static bool Insertar(Paquete paquete)
        {
            string sql = "INSERT INTO Paquetes (direccionEntrega,trackingID,alumno) VALUES(";
            sql = sql + "'" + paquete.DireccionEntrega + "'," + paquete.TrackingID + "," + "Carla Eliana" +  "')";
            return EjecutarNonQuery(sql);
        }


        private static bool EjecutarNonQuery(string sql)
        {
            bool todoOk = false;
            try
            {        
                PaqueteDAO._comando.CommandText = sql;
                PaqueteDAO._conexion.Open();
                PaqueteDAO._comando.ExecuteNonQuery();
                todoOk = true;
            }
            catch (Exception e)
            {
                todoOk = false;
            }
            finally
            {
                if (todoOk)
                    PaqueteDAO._conexion.Close();
            }
            return todoOk;
        }
    }
}
